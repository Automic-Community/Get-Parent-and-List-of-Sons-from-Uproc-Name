#!/bin/sh
####################################################################################
##
## v1.0 - Returns sequencing information on a given Uproc within a Session 
## (List of Sons and of father if the Uproc is not the header of session)
##
## PS Asia - 2013
##
## Note: Has not been tested for DUv5
## Note: Only works locally but could be adapted to work remotely
##
####################################################################################

SESSION=$1
UPROC=$2

getHelp(){
echo  
echo Two Parameters need to be passed:
echo  
echo  1- Session Name \(Must Exist\)
echo  2- Uproc Name \(Must Exist and belong to Session\)
echo  
echo  ex:
echo  $0 \"MY SESSION\" \"MY UPROC\"
echo  
echo Meaning of Output:
echo  
echo  A \-\-\> B: A is father of B
echo  B \<\-\- C: B is son of C
echo  D \<\-\-  : D has no father \(and therefore is the Header\)
echo  E \-\-\>  : E has no son 
echo  
}

## Preliminary Checks ##

## Non emptyness of first and second parameters 
if [ "$SESSION" = "" ]; then 
	echo --- Error! First Parameter should be a Session Name
	getHelp
	exit 1
fi
if [ "$UPROC" = "" ]; then
	echo --- Error! Second Parameter should be a Uproc Name
	getHelp
	exit 1
fi

## Env Variables must be loaded
if [ "$UNI_DIR_EXEC" = "" ]; then
	echo --- Error! it appears that the environment variables for Dollar Universe were not loaded
	echo --> Please Load file unienv.ksh
	getHelp
	exit 1
fi

## Session and Uproc must exist. Uproc must belong to session
SesExist=`$UNI_DIR_EXEC/uxlst SES SES="$SESSION" | wc -l`
if [ $SesExist -le 4 ];then
	echo --- The session $SESSION does not seem to exist!
	exit 1
fi
UprExist=`$UNI_DIR_EXEC/uxlst UPR UPR="$UPROC" | wc -l`
if [ $UprExist -le 4 ];then
        echo --- The Uproc $UPROC does not seem to exist!
        exit 1
fi
UprBelongsToSession=`$UNI_DIR_EXEC/uxshw SES SES="$SESSION" | grep " upr " | grep "$UPROC" | wc -l`
if [ $UprBelongsToSession -lt 1 ]; then
	echo --- Uproc $UPROC does not seem to belong to session $SESSION
	exit 1
fi

## End of Checks ##

##############
##   MAIN   ##
##############

FATHERLIST=./Fathers.list
SONSLIST=./Sons.list

## Generating the list of Fathers and Sons seperatly 
$UNI_DIR_EXEC/uxshw SES SES="$SESSION" LNK | grep "\|\|" | grep -v "NumF" | awk -F\| '{print $3 "|" $6}' | grep -v "^|" > $FATHERLIST 
$UNI_DIR_EXEC/uxshw SES SES="$SESSION" LNK | grep "\|\|" | grep -v "NumF" | awk -F\| '{print $4 "|" $7}' | grep -v "^|" > $SONSLIST 

isUprInFatherList=N
isUprInSonList=N
UPROCID=0

cnt=`cat $FATHERLIST | grep "$UPROC" | wc -l`
if [ $cnt -gt 0 ];then
	isUprInFatherList=Y
fi

cnt=`cat $SONSLIST | grep "$UPROC" | wc -l`
if [ $cnt -gt 0 ];then
        isUprInSonList=Y
fi
 
if [ "$isUprInFatherList" = "Y" ];then
	UPROCID=`cat $FATHERLIST | grep "$UPROC" | head -n 1 | awk -F\| '{print $1}'|sed 's/[[:space:]]//g'`
	i=0
	while read line;do
		i=$((i+1))
		cnt=`echo $line | grep "^$UPROCID" | wc -l`
		if [ $cnt -gt 0 ];then
			ISASON=`sed -n ${i}p $SONSLIST | awk -F\| '{print $2}'`
			echo $ISASON \<\-\- "$UPROC" 
		fi

	done < $FATHERLIST

fi

if [ "$isUprInSonList" = "Y" ];then
        UPROCID=`cat $SONSLIST | grep "$UPROC" | head -n 1 | awk -F\| '{print $1}'|sed 's/[[:space:]]//g'`
	i=0
        while read line;do
        	i=$((i+1))
        	cnt=`echo $line | grep "^$UPROCID" | wc -l`
        	if [ $cnt -gt 0 ];then
        		#ISAFATHER=`sed -n ${i}p $FATHERLIST | awk -F\| '{print $2}'`
			FATHERID=`sed -n ${i}p $FATHERLIST | awk -F\| '{print $1}'|sed 's/[[:space:]]//g'`
			ISAFATHER=`cat $FATHERLIST | grep "^ $FATHERID " | head -n 1 | awk -F\| '{print $2}'`
       			#if [ "$ISAFATHER" = "" ]; then ISAFATHER=`cat $FATHERLIST | grep "  
			echo $ISAFATHER \-\-\> "$UPROC"
		fi
	done < $SONSLIST

fi
if [ "$isUprInFatherList" = "N" ];then echo $UPROC \-\-\> ;fi
if [ "$isUprInSonList" = "N" ];then echo $UPROC \<\-\- ;fi

rm $FATHERLIST
rm $SONSLIST

exit 0

